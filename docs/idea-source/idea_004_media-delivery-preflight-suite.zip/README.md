# メディア納品前チェックスイート 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | WindowsApp |
| No. | 4 |
| 分野 | 検品・品質保証 |
| アイデア | メディア納品前チェックスイート |
| リポジトリ名 | media-delivery-preflight-suite |
| 概要 | 画像、音声、動画、BOOTH素材、zip、メタ情報、容量を検査する。 入力、確認、履歴保存、次アクションを同じ作業単位で扱えるようにする。 |
| 課題 | 納品直前に形式、命名、容量、説明文の抜けが残る。 |
| 類似サービス・アプリ | Microsoft PowerToys, Notion, Obsidian, Ditto, ShareX, FreeFileSync, GitHub Desktop |
| 差別化ポイント | 制作物カードに検品結果と修正候補を付ける。 |

## 目的

このZIPには、`WindowsApp` 領域のアイデア `メディア納品前チェックスイート` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
